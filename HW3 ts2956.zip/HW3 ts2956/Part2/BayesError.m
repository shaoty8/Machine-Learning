function error = BayesError(Xtrain,Y,X,label)
%the error rate is 0.0820, which is 8.2%, the accuracy is 91.8%.
        n = 500;
        a = 0;
        mu1 = 0;
        mu0 = 0;
        for i = 1:n
            if Y(i) == 1
                mu1 = mu1 + Xtrain(2:10,i);
                a = a + 1;
            else
                mu0 = mu0 + Xtrain(2:10,i);
            end
        end
        
        mu1 = mu1/a;
        mu0 = mu0/(n-a);
        pi1 = a/n;
        pi0 = 1 - pi1;
        
        sigma = zeros(9,9);
        for j = 1:n
            if Y(j) == 1
                sigma = sigma + (Xtrain(2:10,j) - mu1)*(Xtrain(2:10,j) - mu1)';
            else
                sigma = sigma + (Xtrain(2:10,j) - mu0)*(Xtrain(2:10,j) - mu0)';
            end
        end
        sigma = sigma/n;
        
        omega0 = log(pi1/pi0) - 0.5*(mu1 + mu0)' * inv(sigma) * (mu1 - mu0);
        omega1 = inv(sigma) * (mu1 - mu0);
        Bomega = [omega0;omega1];
        
        error = 0;
        for k = 1:183
            if sign(X(:,k)'*Bomega) ~= label(k)
                error = error + 1;
            end
        end
        
        error = error/183;
