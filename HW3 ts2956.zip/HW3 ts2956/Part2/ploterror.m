%plot error(1*1000) by the scale of T
TrainError = zeros(1,1000);
TestError = zeros(1,1000);
for t = 1:1000
    [TrainError(t),TestError(t)] = Error(Alpha, Omega, Xtrain,Y,t,Xtest,Ytest);
end
plot(T,TrainError,'color','r'); 
hold on;
plot(T,TestError,'color','b');