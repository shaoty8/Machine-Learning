function [Omega,Alpha,Epsilon,P] = BayesBoost(T,Xtrain,Y)
%omega is the function parameter, Omega stores each omega during iterations
%T=1000, (X,label) is the data set
    n = 500;
    %initialize p
    p = ones(1,n);
    p = p / n ;
    
    %store all T omegas, alphas and epsilons in three matrix for calculating errors
    Omega = zeros(10,T);
    Alpha = zeros(1,T);
    Epsilon = zeros(1,T);
    P = zeros(T,n);
    
    for t = 1:T
        %Bootstrap
        c = randomsample(n,p);
        %data(x,y) in bootstrap set
        y = Y(c);
        x = Xtrain(:,c);
        
        %a is the number of y=1
        %compute mu1(t),mu0(t) and sigma(t)
        a = 0;
        mu1 = zeros(9,1);
        mu0 = zeros(9,1);
        for i = 1:n
            if y(i) == 1
                mu1 = mu1 + x(2:10,i);
                a = a + 1;
            else
                mu0 = mu0 + x(2:10,i);
            end
        end
        
        mu1 = mu1/a;
        mu0 = mu0/(n-a);
        pi1 = a/n;
        pi0 = 1 - pi1;
        
        sigma = zeros(9,9);
        for j = 1:n
            if y(j) == 1
                sigma = sigma + (x(2:10,j) - mu1)*(x(2:10,j) - mu1)';
            else
                sigma = sigma + (x(2:10,j) - mu0)*(x(2:10,j) - mu0)';
            end
        end
        sigma = sigma/n;
        
        omega0 = log(pi1/pi0) - 0.5*(mu1 + mu0)' * (sigma)^(-1) * (mu1 - mu0);
        omega1 = (sigma)^(-1) * (mu1 - mu0);
        %compute and combine omega(:,t)
        omega = [omega0;omega1];
        
        %compute epsilon(t) and alpha(t)
        epsilon = 0;
        for m = 1:n
            if sign(Xtrain(:,m)' * omega) ~= Y(m)
                epsilon = epsilon + p(m);
            end
        end
        alpha = 0.5 * log((1-epsilon)/epsilon);
        
        for k = 1:n
                p(k) = p(k) * exp(-alpha * Y(k) * sign(Xtrain(:,k)' * omega));
        end
        
        %normalize p
        psum = sum(p);
        p = p/psum;
        
        %store all the p, omega, alpha and epsilon
        P(t,:) = p;
        Omega(:,t) = omega;
        Alpha(t) = alpha;
        Epsilon(t) = epsilon;
    end
    
    
                