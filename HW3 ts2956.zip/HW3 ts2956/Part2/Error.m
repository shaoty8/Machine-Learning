function [n,m] = Error(Alpha, Omega, Xtrain,Y,T,Xtest,Ytest)
%compute error rate under a certain numbers T of bootstrap
a = zeros(1,500); % a is the predict answer for training set
%compute a
for j = 1:500
    for i = 1:T
        a(j) = a(j) + Alpha(i) * sign(Xtrain(:,j)'*Omega(:,i));
    end
    a(j) = sign(a(j));
end
%compute how many errors in a
n = 0;
for k = 1:500
    if a(k) ~= Y(k)
        n = n+1;
    end
end

b = zeros(1,183);% b is the predict answer for testing set
for j = 1:183
    for i = 1:T
        a(j) = a(j) + Alpha(i) * sign(Xtest(:,j)'*Omega(:,i));
    end
    a(j) = sign(a(j));
end

m = 0;
%number of errors in b
for k = 1:183
    if a(k) ~= Ytest(k)
        m = m+1;
    end
end
%compute each error rate
n = n/500;
m = m/183;