function c = randomsample(n,w)
%Bootstrap function
    k = size(w);
    c = zeros(1,n);
    
    %cumulative distribution of w
    P = cumsum(w);
    R = rand(n,1);
    p = @(r) find(r<P,1,'first'); % find the 1st index s.t. r<P(i);
    % Results of the random 
    c = arrayfun(p,R);