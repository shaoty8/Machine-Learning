function [Omega,Alpha,Epsilon,P] = LogisticBoost(T,Xtrain,Y)
%omega is the function parameter, Omega stores each omega during iterations
%T=1000, (X,label) is the data set
    n = 500;
    %initialize p
    p = ones(1,n);
    p = p / n ;
    
    %store all T omegas, alphas and epsilons in three matrix for calculating errors
    Omega = zeros(10,T);
    Alpha = zeros(1,T);
    Epsilon = zeros(1,T);
    P = zeros(T,n);
    
    for t = 1:T
        %Bootstrap
        c = randomsample(n,p);
        %data(x,y) in bootstrap set
        y = Y(c);
        x = Xtrain(:,c);
        omega = zeros(10,1);
        %compute omega(:,t)
        for i = 1:n
            
            sigma = 1/(1 + exp(-y(i)* x(:,i)' * omega));
            omega = omega + 0.1 * (1 - sigma)* y(i) * x(:,i);
        end
        
        
        %compute epsilon(:,t) and alpha(t)
        epsilon = 0;
        
        
        for m = 1:n
            if sign(Xtrain(:,m)' * omega) ~= Y(m)
                epsilon = epsilon + p(m);
            end
        end
        alpha = 0.5 * log((1-epsilon)/epsilon);
        
        for k = 1:n
                p(k) = p(k) * exp(-alpha * Y(k) * sign(Xtrain(:,k)' * omega));
            
        end
        
        %normalize p
        psum = sum(p);
        p = p/psum;
        %store p,omega,alpha and epsilon
        P(t,:) = p;
        Omega(:,t) = omega;
        Alpha(t) = alpha;
        Epsilon(t) = epsilon;
    end
    
    
                