function accuracy = LogisticError(Xtrain,Y,Xtest,Ytest)
%compute the accuracy of Logistic regression without boost
%the accruacy is 82.51%
n = length(Y);
omega = zeros(10,1);
for i = 1:n
    sigma = 1/(1 + exp(-Y(i)* Xtrain(:,i)' * omega));
    omega = omega + 0.1 * (1 - sigma)* Y(i) * Xtrain(:,i);
end

m = length(Ytest);
answer = zeros(1,m);
for j = 1:m
    answer(j) = sign(Xtest(:,j)' * omega);
end

error = 0;
for k = 1:m
    if answer(k) ~= Ytest(k)
        error = error + 1;
    end
end
accuracy = 1 - error/m;
    